<?php
define("APP_ROOT", dirname(__FILE__));
define("WEB_ROOT", 'http://'.$_SERVER['HTTP_HOST'].'/');
define("DB_NAME", 'MWS');
define("TBL_NAME", 'HomeData');
define("DB_ADDR", 'localhost');
define("DB_USR", 'root');
define("DB_PSW", '198579');
?>

