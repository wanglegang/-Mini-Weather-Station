<ul class="nav nav-list">
			<li>
				<a href="banlist.php">Ban Ip's</a>
			</li>
			<li>
				<a href="exportList.php"> Downlaods/ Exports till date</a>
			</li>
			
</ul>